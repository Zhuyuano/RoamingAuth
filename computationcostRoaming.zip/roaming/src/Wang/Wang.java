package Wang;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import static java.lang.System.out;

public class Wang {

    public static void setup(String pairingFile, String publicFile, String mskFile, String KGC) {

        Pairing bp = PairingFactory.getPairing(pairingFile);
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp = new Properties();
        PubProp.setProperty("P", P.toString());
        storePropToFile(PubProp, publicFile);

        Properties mskProp = loadPropFromFile(mskFile);
        Element s = bp.getZr().newRandomElement().getImmutable();
        mskProp.setProperty("s_" + KGC, Base64.getEncoder().encodeToString(s.toBytes()));
        storePropToFile(mskProp, mskFile);

        Element P_pub = P.powZn(s).getImmutable();
        PubProp.setProperty("P_pub_" + KGC, P_pub.toString());
        storePropToFile(PubProp, publicFile);
    }

    public static void registration(String pairingFile, String publicFile, String pkFile, String skFile, String KGC, String ID) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties pubProp = loadPropFromFile(publicFile);
        String Pstr = pubProp.getProperty("P");
        String P_pubstr = pubProp.getProperty("P_pub_" + KGC);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp = loadPropFromFile(pkFile);
        Properties skp = loadPropFromFile(skFile);

        Element x = bp.getZr().newRandomElement().getImmutable();
        Element X = P.powZn(x).getImmutable();
        Element r = bp.getZr().newRandomElement().getImmutable();
        Element R = P.powZn(r).getImmutable();
        byte[] bH1 = sha1(P_pub.toString() + ID + X.toString() + R.toString());
        Element H1 = bp.getZr().newElementFromHash(bH1, 0, bH1.length).getImmutable();
        Element d = r.powZn(P_pub.powZn(H1)).getImmutable();

        pkp.setProperty("X_" + ID, X.toString());
        pkp.setProperty("R_" + ID, R.toString());
        skp.setProperty("x_" + ID, Base64.getEncoder().encodeToString(x.toBytes()));
        skp.setProperty("d_" + ID, Base64.getEncoder().encodeToString(d.toBytes()));
        storePropToFile(pkp, pkFile);
        storePropToFile(skp, skFile);
    }

    public static void keyNegotiation(String pairingFile, String publicFile, String pkFile, String skFile, String KGC, String serv_t) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties pubProp = loadPropFromFile(publicFile);
        String Pstr = pubProp.getProperty("P");
        String P_pubstr = pubProp.getProperty("P_pub_" + KGC);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp = loadPropFromFile(pkFile);
        Properties skp = loadPropFromFile(skFile);

        Element d = bp.getZr().newRandomElement().getImmutable();
        Element PK_serv_t = P.powZn(d).getImmutable();
        Element sk_serv_t = d.add(bp.getZr().newRandomElement().getImmutable());

        pkp.setProperty("PK_serv_t", PK_serv_t.toString());
        skp.setProperty("sk_serv_t", Base64.getEncoder().encodeToString(sk_serv_t.toBytes()));
        storePropToFile(pkp, pkFile);
        storePropToFile(skp, skFile);
    }

    public static void messageSigningEncryption(String pairingFile, String publicFile, String pkFile, String skFile, String KGC, String ID, String message) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties pubProp = loadPropFromFile(publicFile);
        String Pstr = pubProp.getProperty("P");
        String P_pubstr = pubProp.getProperty("P_pub_" + KGC);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp = loadPropFromFile(pkFile);
        Properties skp = loadPropFromFile(skFile);

        Element x = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(skp.getProperty("x_" + ID))).getImmutable();
        Element sk_i = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(skp.getProperty("d_" + ID))).getImmutable();
        Element w = bp.getZr().newRandomElement().getImmutable();
        Element W = P.powZn(w).getImmutable();
        Element u = bp.getZr().newRandomElement().getImmutable();
        Element U = P.powZn(w).getImmutable();
        byte[] bH3 = sha1(pkp.getProperty("PID_" + ID) + W.toString() + U.toString());
        Element h3 = bp.getZr().newElementFromHash(bH3, 0, bH3.length).getImmutable();
        byte[] bH = sha1(ID + pkp.getProperty("PK_serv_t") + pkp.getProperty("PK_serv_t"));
        Element h = bp.getZr().newElementFromHash(bH, 0, bH.length).getImmutable();
        byte[] bH5 = sha1(message);
        Element h5 = bp.getZr().newElementFromHash(bH5, 0, bH5.length).getImmutable();
        Element sigma = sk_i.mul(h5.mul(w.add(h.add(h3).mul(u)))).invert().getImmutable();
        Element s = bp.getZr().newElementFromHash(U.toBytes(), 0, U.toBytes().length).getImmutable();
        Element Y_i = U.mul(bp.getG1().newElementFromBytes(pkp.getProperty("PK_serv_t").getBytes())).getImmutable();

        byte[] encryptedMessage = (s.toString() + "|" + Y_i.toString()).getBytes();
        byte[] signature = sigma.toBytes();

        //out.println("Encrypted Message: " + new String(encryptedMessage));
        //out.println("Signature: " + Base64.getEncoder().encodeToString(signature));
    }

    public static void messageDecryptionVerification(String pairingFile, String publicFile, String pkFile, String skFile, String KGC, String ID, String encryptedMessage, byte[] signature) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties pubProp = loadPropFromFile(publicFile);
        String Pstr = pubProp.getProperty("P");
        String P_pubstr = pubProp.getProperty("P_pub_" + KGC);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp = loadPropFromFile(pkFile);
        Properties skp = loadPropFromFile(skFile);

        Element sk_serv_t = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(skp.getProperty("sk_serv_t"))).getImmutable();
        String[] parts = encryptedMessage.split("\\|");
        Element U_prime = bp.getG1().newElementFromBytes(parts[0].getBytes()).getImmutable();
        Element m_prime = bp.getG1().newElementFromHash(sha1(U_prime.toString()), 0, sha1(U_prime.toString()).length).getImmutable();
        Element s_prime = bp.getG1().newElementFromBytes(parts[0].getBytes()).getImmutable();

        Element m = m_prime.add(s_prime).getImmutable();
        Element sigma_prime = bp.getG1().newElementFromBytes(signature).getImmutable();

        byte[] bH3_prime = sha1(pkp.getProperty("PID_" + ID) + U_prime.toString());
        Element h3_prime = bp.getZr().newElementFromHash(bH3_prime, 0, bH3_prime.length).getImmutable();
        byte[] bH = sha1(ID + pkp.getProperty("PK_serv_t") + pkp.getProperty("PK_serv_t"));
        Element h = bp.getZr().newElementFromHash(bH, 0, bH.length).getImmutable();

        Element left = U_prime.add(U_prime.powZn(h3_prime)).mul(sigma_prime).getImmutable();
        Element right = bp.getG1().newElementFromHash(sha1(m.toString()), 0, sha1(m.toString()).length).getImmutable().mul(U_prime);


    }


    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        String dir = "./storeFile/Wang/"; // 根路径
        String pairingParametersFileName = dir + "a.properties";
        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName = dir + "pk.properties";
        String secretKeyFileName = dir + "sk.properties";
        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();
            String TA = "RSU";
            String ID = "Device1";
            String TAb = "RSUB";
            String IDb = "DeviceB";
            String encryptedMessage = "Encrypted Message Encrypted Message";
            byte[] signature = {123, 45};
            setup(pairingParametersFileName, publicParameterFileName, mskFileName, TA);

            registration(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, TA, ID);
            keyNegotiation(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, TA, "serv_t");
            messageSigningEncryption(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, TA, ID, "Hello, World!");
            messageDecryptionVerification(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, TA, ID, encryptedMessage, signature);
            long end = System.currentTimeMillis();
            System.out.println((end - start)*2);
        }
    }

}