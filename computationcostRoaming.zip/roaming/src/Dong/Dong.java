package Dong;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import static java.lang.System.out;

public class Dong{


    public static void setup0(String pairingFile,String publicFile) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

    }
    public static void Registration_KGC(String pairingFile, String publicFile,String mskFile,String KGC_i) {
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGCX、Y的主私钥
        Element PR_i = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("PR_"+KGC_i, Base64.getEncoder().encodeToString(PR_i.toBytes()));//element和string类型之间的转换需要通过bytes
        storePropToFile(mskProp, mskFile);

        //设置KGCX、Y的主公钥
        Element PKi = P.powZn(PR_i).getImmutable();
        PubProp.setProperty("PK_"+KGC_i,PKi.toString());
        storePropToFile(PubProp,publicFile);
    }


    //Registration阶段
    public static void Registration_Industrial(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String KGC_i,String ID_i) throws NoSuchAlgorithmException {

        //获得KGC的主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String PKistr=pubProp.getProperty("PK_"+KGC_i);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element PKi = bp.getG1().newElementFromBytes(PKistr.getBytes()).getImmutable();
        //获得主私钥
        Properties mskp=loadPropFromFile(mskFile);
        String PR_istr=mskp.getProperty("PR_"+KGC_i);
        Element PR_i=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(PR_istr)).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //为企业生成公私钥
        //KGC does
        Element Ar2_i=bp.getZr().newRandomElement().getImmutable();
        Element AR2_i=P.powZn(Ar2_i).getImmutable();
        byte[] bH1_i=sha1(ID_i);
        Element Ah1_i=bp.getG1().newElementFromHash(bH1_i,0,bH1_i.length).getImmutable();
        Element sigma_i=PR_i.add(Ah1_i.powZn(Ar2_i)).getImmutable();
        //KGC 发送σ，AR2给企业作为其部分私钥，并进行验证，then企业据其产生私钥
        //企业 does
        Element l1= PKi.add(AR2_i.mul(Ah1_i)).getImmutable();
        Element r1= P.mul(sigma_i).getImmutable();

        Element Ar1_i=bp.getG1().newRandomElement().getImmutable();
        Element AR1_i=P.mul(Ar1_i).getImmutable();
        Element S_i=sigma_i.add(Ar1_i).getImmutable();
        Element P_i= P.mul(S_i).getImmutable();

        pkp.setProperty("P_"+ID_i,P_i.toString());
        skp.setProperty("S_"+ID_i,Base64.getEncoder().encodeToString(S_i.toBytes()));
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);
    }


    public static void crossDomainAKA(String pairingFile,String publicFile,String pkFile,String skFile,String veriFile,String KGC_X,String KGC_Y,String ID_i,String ID_j) throws NoSuchAlgorithmException {
        //车辆间跨域认证和密钥协商
        //获取KGCX、Y的主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String PKistr=pubProp.getProperty("PK_"+KGC_X);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element PKi = bp.getG1().newElementFromBytes(PKistr.getBytes()).getImmutable();

        String PKjstr=pubProp.getProperty("PK_"+KGC_Y);
        Element PKj = bp.getG1().newElementFromBytes(PKjstr.getBytes()).getImmutable();


        //获取企业A,B的公钥 和私钥
        Properties pkp=loadPropFromFile(pkFile);
        String P_istr=pkp.getProperty("P_"+ID_i);
        Element P_i=bp.getG1().newElementFromBytes(P_istr.getBytes()).getImmutable();
        String P_jstr=pkp.getProperty("P_"+ID_j);
        Element P_j=bp.getG1().newElementFromBytes(P_jstr.getBytes()).getImmutable();

        Properties skp=loadPropFromFile(skFile);
        String S_istr=skp.getProperty("S_"+ID_i);
        Element S_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(S_istr)).getImmutable();
        String S_jstr=skp.getProperty("S_"+ID_j);
        Element S_j=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(S_jstr)).getImmutable();

        //企业A does,send(rpb,Ah3,QAB,t1) to B
        Element t1_i=bp.getZr().newRandomElement().getImmutable();
        Element Ar3_i=bp.getZr().newRandomElement().getImmutable();
        Element rpb_i=P_i.powZn(Ar3_i).getImmutable();
        byte[] bAh3_i=sha1(ID_i+ID_j+Ar3_i.toString()+t1_i.toString());
        Element Ah3_i=bp.getZr().newElementFromHash(bAh3_i,0,bAh3_i.length).getImmutable();
        Element QAB_i= S_i.powZn(Ar3_i.add(Ah3_i)).getImmutable();
        Properties verip=loadPropFromFile(veriFile);
        verip.setProperty("rpb_"+ID_i,rpb_i.toString());
        //verip.setProperty("Ah3_"+ID_i,Ah3_i.toString());
        verip.setProperty("QAB_"+ID_i,QAB_i.toString());
        verip.setProperty("t1_"+ID_i,t1_i.toString());
        storePropToFile(verip,veriFile);

        //B does,验证，send (rpa,bh3,QBA,t2) to A
        Element t2_j=bp.getZr().newRandomElement().getImmutable();
        Element Br3_j=bp.getZr().newRandomElement().getImmutable();
        Element l2= QAB_i.powZn(P_j.powZn(Br3_j)).getImmutable();
        Element r2 = S_j.powZn(P_i.powZn(Ah3_i.mul(Br3_j))).add(S_j.powZn(rpb_i.powZn(Br3_j))).getImmutable();
//        if(l2==r2){
//            out.println("验证成功1");
//        }
//        else{
//            out.println("验证失败1");
//        }

        Element rpa_j=P_j.powZn(Br3_j).getImmutable();
        byte[] bBh3_j=sha1(ID_i+ID_j+Br3_j.toString()+t1_i.toString()+t2_j.toString());
        Element Bh3_j=bp.getZr().newElementFromHash(bBh3_j,0,bBh3_j.length).getImmutable();
        Element QBA_j=S_j.powZn(Br3_j.add(Bh3_j)).getImmutable();
        //A验证
        Element l3= QBA_j.powZn(P_i.powZn(Ar3_i)).getImmutable();
        Element r3 = S_i.powZn(P_j.powZn(Bh3_j.mul(Ar3_i))).add(S_i.powZn(rpa_j.powZn(Ar3_i))).getImmutable();
//        if(l3==r3){
//            out.println("验证成功2");
//        }
//        else{
//            out.println("验证失败2");
//        }
        // 会话密钥 stage
        //企业A产生会话密钥SKab，并讲加密后的密文A发送给B
        Element SKab_i=S_i.powZn(rpa_j.powZn(Ar3_i)).getImmutable();
        byte[] bAh4_i=sha1(QAB_i.toString()+QBA_j.toString()+Ah3_i.toString()+Bh3_j.toString()+t1_i.toString()+t2_j.toString());
        Element Ah4_i=bp.getZr().newElementFromHash(bAh4_i,0,bAh4_i.length).getImmutable();

        byte[] bAciptext_i=sha1(Ah4_i.toString()+SKab_i.toString());
        Element Aciptext_i=bp.getZr().newElementFromHash(bAciptext_i,0,bAciptext_i.length).getImmutable();
        //B
        Element SKab_j=S_j.powZn(rpb_i.powZn(Br3_j)).getImmutable();
        byte[] bBh4_j=sha1(QAB_i.toString()+QBA_j.toString()+Ah3_i.toString()+Bh3_j.toString()+t1_i.toString()+t2_j.toString());
        Element Bh4_j=bp.getZr().newElementFromHash(bBh4_j,0,bBh4_j.length).getImmutable();
        byte[] bBciptext_j=sha1(Bh4_j.toString()+SKab_j.toString());

        skp.setProperty("SK_ab_",SKab_i.toString());
        skp.setProperty("SK_ab_",SKab_j.toString());
        storePropToFile(skp,skFile);

    }




    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Dong/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String verifyFileName = dir+"veri.properties";
        String KGC_X = "KGC_X";
        String KGC_Y="KGC_Y";
        String ID_i="A";
        String ID_j="B";

        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();
            setup0(pairingParametersFileName,publicKeyFileName);

            Registration_KGC(pairingParametersFileName,publicParameterFileName,mskFileName,KGC_X);
            Registration_KGC(pairingParametersFileName,publicParameterFileName,mskFileName,KGC_Y);
            Registration_Industrial(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC_X,ID_i);
            Registration_Industrial(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC_Y,ID_j);
            crossDomainAKA(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,verifyFileName,KGC_X,KGC_Y,ID_i,ID_j);

            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }




    }
}
