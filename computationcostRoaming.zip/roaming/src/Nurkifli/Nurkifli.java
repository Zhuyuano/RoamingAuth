package Nurkifli;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import static java.lang.System.out;

public class Nurkifli {

    // System Initialization
    public static void systemInitialization(String pairingFile, String publicFile, String mskFile, String KGC) {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Element g = bp.getG1().newRandomElement().getImmutable();
        Element g0 = bp.getG1().newRandomElement().getImmutable();
        Element h = bp.getG1().newRandomElement().getImmutable();
        Element alpha = bp.getZr().newRandomElement().getImmutable();
        Element g1 = g.powZn(alpha).getImmutable();
        Element g2 = g0.powZn(alpha).getImmutable();
        Element u = bp.pairing(g0, g1).getImmutable();

        Properties pubProp = new Properties();
        pubProp.setProperty("g", g.toString());
        pubProp.setProperty("g0", g0.toString());
        pubProp.setProperty("h", h.toString());
        pubProp.setProperty("g1", g1.toString());
        pubProp.setProperty("g2", g2.toString());
        pubProp.setProperty("u", u.toString());
        storePropToFile(pubProp, publicFile);

        Properties mskProp = loadPropFromFile(mskFile);
        Element sA = bp.getZr().newRandomElement().getImmutable();
        mskProp.setProperty("s_A", Base64.getEncoder().encodeToString(sA.toBytes()));
        storePropToFile(mskProp, mskFile);

        Element P_pub_A = g.powZn(sA).getImmutable();
        pubProp.setProperty("P_pub_A", P_pub_A.toString());
        storePropToFile(pubProp, publicFile);
    }

    // Registration phase between FA and HA via secure channel
    public static void registrationPhaseBetweenFAandHA(String pairingFile, String publicFile, String mskFileA, String pkFile, String skFile, String KGC, String FA_i) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties pubProp = loadPropFromFile(publicFile);
        String Pstr = pubProp.getProperty("g");
        String P_pubstr = pubProp.getProperty("P_pub_A");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties mskPropA = loadPropFromFile(mskFileA);
        Element sA = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(mskPropA.getProperty("s_A"))).getImmutable();

        Element x_FA = bp.getZr().newRandomElement().getImmutable();
        Element X_FA = P.powZn(x_FA).getImmutable();
        Element r_FA = bp.getZr().newRandomElement().getImmutable();
        Element R_FA = P.powZn(r_FA).getImmutable();
        byte[] bH1_i = sha1(P_pub.toString() + FA_i + X_FA.toString() + R_FA.toString());
        Element H1_i = bp.getZr().newElementFromHash(bH1_i, 0, bH1_i.length).getImmutable();
        Element d_FA = r_FA.powZn(P_pub.powZn(H1_i)).getImmutable();

        Properties pkp = loadPropFromFile(pkFile);
        Properties skp = loadPropFromFile(skFile);

        pkp.setProperty("X_" + FA_i, X_FA.toString());
        pkp.setProperty("R_" + FA_i, R_FA.toString());
        skp.setProperty("x_" + FA_i, Base64.getEncoder().encodeToString(x_FA.toBytes()));
        skp.setProperty("d_" + FA_i, Base64.getEncoder().encodeToString(d_FA.toBytes()));
        storePropToFile(pkp, pkFile);
        storePropToFile(skp, skFile);
    }

    // Registration process between MU and HA via secure channel
    public static void registrationProcessBetweenMUandHA(String pairingFile, String publicFile, String pkFile, String skFile, String KGC, String ID_i) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties pubProp = loadPropFromFile(publicFile);
        String Pstr = pubProp.getProperty("g");
        String P_pubstr = pubProp.getProperty("P_pub_A");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp = loadPropFromFile(pkFile);
        Properties skp = loadPropFromFile(skFile);

        Element u_i = bp.getZr().newRandomElement().getImmutable();
        Element U_i = P.powZn(u_i).getImmutable();
        Element r_i = bp.getZr().newRandomElement().getImmutable();
        Element R_i = P.powZn(r_i).getImmutable();
        byte[] bID_i = ID_i.getBytes();
        byte[] bH0_i = sha1(P_pub.toString() + R_i.toString());
        int n = Math.max(bH0_i.length, bID_i.length);
        int m = Math.min(bH0_i.length, bID_i.length);
        byte[] bPID_i = new byte[n];
        for (int i = 0; i < m; i++)
            bPID_i[i] = (byte) (bH0_i[i] ^ bID_i[i]);
        Element PID_i = bp.getG1().newElementFromHash(bPID_i, 0, bPID_i.length).getImmutable();

        byte[] bH1_i = sha1(P_pub.toString() + PID_i.toString() + U_i.toString() + R_i.toString());
        Element H1_i = bp.getZr().newElementFromHash(bH1_i, 0, bH1_i.length).getImmutable();
        Element d_i = r_i.powZn(P_pub.powZn(H1_i));

        pkp.setProperty("PID_" + ID_i, PID_i.toString());
        pkp.setProperty("X_" + ID_i, U_i.toString());
        pkp.setProperty("R_" + ID_i, R_i.toString());
        skp.setProperty("x_" + ID_i, Base64.getEncoder().encodeToString(u_i.toBytes()));
        skp.setProperty("d_" + ID_i, Base64.getEncoder().encodeToString(d_i.toBytes()));
        storePropToFile(pkp, pkFile);
        storePropToFile(skp, skFile);
    }

    // Mutual Authentication roaming service between MU and FA helped by HA
    public static void mutualAuthenticationRoamingService(String pairingFile, String publicFile, String pkFile, String skFile, String veriFile, String certiFile, String KGC, String FA_i, String ID_i) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties pubProp = loadPropFromFile(publicFile);
        String Pstr = pubProp.getProperty("g");
        String P_pubstr = pubProp.getProperty("P_pub_A");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Element FA_iElement = bp.getG1().newElementFromBytes(FA_i.getBytes()).getImmutable();
        Properties pkp = loadPropFromFile(pkFile);
        String PID_iStr = pkp.getProperty("PID_" + ID_i);
        Element PID_i = bp.getG1().newElementFromBytes(PID_iStr.getBytes()).getImmutable();

        String X_iStr = pkp.getProperty("X_" + ID_i);
        Element X_i = bp.getG1().newElementFromBytes(X_iStr.getBytes()).getImmutable();
        String R_iStr = pkp.getProperty("R_" + ID_i);
        Element R_i = bp.getG1().newElementFromBytes(R_iStr.getBytes()).getImmutable();
        String X_FAStr = pkp.getProperty("X_" + FA_i);
        Element X_FA = bp.getG1().newElementFromBytes(X_FAStr.getBytes()).getImmutable();
        String R_FAStr = pkp.getProperty("R_" + FA_i);
        Element R_FA = bp.getG1().newElementFromBytes(R_FAStr.getBytes()).getImmutable();

        Properties skp = loadPropFromFile(skFile);
        String x_iStr = skp.getProperty("x_" + ID_i);
        Element x_i = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_iStr)).getImmutable();
        String d_iStr = skp.getProperty("d_" + ID_i);
        Element d_i = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_iStr)).getImmutable();
        String x_FAStr = skp.getProperty("x_" + FA_i);
        Element x_FA = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_FAStr)).getImmutable();
        String d_FAStr = skp.getProperty("d_" + FA_i);
        Element d_FA = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_FAStr)).getImmutable();
        // Perform mutual authentication and key agreement
        Element t0_i = bp.getZr().newRandomElement().getImmutable();
        Element t1_i = bp.getZr().newRandomElement().getImmutable();
        Element T0_i = P.powZn(t0_i).getImmutable();
        Element T1_i = P.powZn(t1_i).getImmutable();
        byte[] bh1_FA = sha1(P_pub.toString() + FA_i + X_FA.toString() + R_FA.toString());
        Element h1_FA = bp.getZr().newElementFromHash(bh1_FA, 0, bh1_FA.length).getImmutable();
        Element Q0_i = t0_i.powZn(X_FA.add(R_FA.add(P_pub.powZn(h1_FA))));
        byte[] bhQ0_i = sha1(Q0_i.toString());
        Element hQ0_i = bp.getZr().newElementFromHash(bhQ0_i, 0, bhQ0_i.length).getImmutable();
        Element temp0_i = PID_i.powZn(T1_i).getImmutable();
        byte[] btemp0_i = temp0_i.toBytes();
        int n = Math.max(bhQ0_i.length, btemp0_i.length);
        int m = Math.min(bhQ0_i.length, btemp0_i.length);
        byte[] bM0_i = new byte[n];
        for (int i = 0; i < m; i++)
            bM0_i[i] = (byte) (bhQ0_i[i] ^ btemp0_i[i]);
        Element M0_i = bp.getZr().newElementFromHash(bM0_i, 0, bM0_i.length).getImmutable();
        Element Gamma1_i = bp.getG1().newRandomElement().getImmutable();
        byte[] bh2_i = sha1(PID_i.toString() + M0_i.toString() + X_i.toString() + R_i.toString() + T1_i.toString() + Gamma1_i.toString());
        Element h2_i = bp.getZr().newElementFromHash(bh2_i, 0, bh2_i.length).getImmutable();
        byte[] bh3_i = sha2(PID_i.toString() + M0_i.toString() + X_i.toString() + R_i.toString() + T1_i.toString() + Gamma1_i.toString());
        Element h3_i = bp.getZr().newElementFromHash(bh2_i, 0, bh2_i.length).getImmutable();
        Element sigma_i = t1_i.add(h2_i.mul(x_i).add(h3_i.mul(d_i)));

        Properties verip = loadPropFromFile(veriFile);

        // FA_i verifies Vi's signature
        byte[] bh1_i = sha1(P_pub.toString() + PID_i.toString() + X_i.toString() + R_i.toString());
        Element h1_i = bp.getZr().newElementFromHash(bh1_i, 0, bh1_i.length).getImmutable();

        Element sigma_iP = P.powZn(sigma_i).getImmutable();
        Element sigmaiP = (T1_i.add(X_i.powZn(h2_i))).add((R_i.add(P_pub.powZn(h1_i))).powZn(h3_i)).getImmutable();

        if (sigma_iP.isEqual(sigmaiP)) {
            // If FA_i verification is successful
            // out.println("FA_i verification successful");
        } else {
            out.println("FA_i verification failed");
        }
        // FA_i sends a message to Vi
        Element t2_i = bp.getZr().newRandomElement().getImmutable();
        Element t3_i = bp.getZr().newRandomElement().getImmutable();
        Element T2_i = P.powZn(t0_i).getImmutable();
        Element T3_i = P.powZn(t1_i).getImmutable();
        Element Q1_i = (X_i.add(R_i.add(P_pub.powZn(h1_i)))).powZn(t2_i);
        byte[] bhQ1_i = sha1(Q0_i.toString());
        Element hQ1_i = bp.getZr().newElementFromHash(bhQ1_i, 0, bhQ1_i.length).getImmutable();
        Element Di = bp.getG1().newRandomElement().getImmutable();
        Element texti = bp.getG1().newRandomElement().getImmutable();

        Element omega_i = PID_i.add(Di.add(texti)).getImmutable();
        Element temp1_i = omega_i.add(T3_i).getImmutable();
        byte[] btemp1_i = temp1_i.toBytes();
        int c = Math.max(bhQ1_i.length, btemp1_i.length);
        int d = Math.min(bhQ1_i.length, btemp1_i.length);
        byte[] bM1_i = new byte[n];
        for (int i = 0; i < m; i++)
            bM1_i[i] = (byte) (bhQ1_i[i] ^ btemp1_i[i]);
        Element Gamma2_i = bp.getG1().newRandomElement().getImmutable();
        byte[] bh2_FA = sha1(omega_i.toString() + X_FA.toString() + R_FA.toString() + T3_i.toString());
        Element h2_FA = bp.getZr().newElementFromHash(bh2_FA, 0, bh2_FA.length).getImmutable();
        byte[] bh3_FA = sha2(omega_i.toString() + X_FA.toString() + R_FA.toString() + T3_i.toString());
        Element h3_FA = bp.getZr().newElementFromHash(bh2_FA, 0, bh3_FA.length).getImmutable();
        Element sigma_FA_i = t3_i.add(h2_FA.mul(x_FA).add(h3_FA.mul(d_FA)));
        verip.setProperty("h1_" + ID_i, h1_i.toString());
        verip.setProperty("h2_FA" + FA_i, h2_FA.toString());
        verip.setProperty("h3_FA" + FA_i, h3_FA.toString());

        Properties certiP = loadPropFromFile(certiFile);
        // Vi verifies FA_i's signature
        Element sigma_FA_iP = P.powZn(sigma_FA_i).getImmutable();
        Element sigma_FA_P = T3_i.add(X_FA.powZn(h2_FA)).add((R_FA.add(P_pub.powZn(h1_FA))).powZn(h3_FA)).getImmutable();
        if (sigma_FA_iP.isEqual(sigma_FA_iP)) {
            // If Vi verification is successful, keep FA_i's generated certificate
            certiP.setProperty("T3_" + ID_i, Base64.getEncoder().encodeToString(T3_i.toBytes()));
            certiP.setProperty("sigma_FA_V_" + ID_i, Base64.getEncoder().encodeToString(sigma_FA_i.toBytes()));
            certiP.setProperty("omega_" + ID_i, Base64.getEncoder().encodeToString(omega_i.toBytes()));
            // out.println("FA_i verification successful");
        } else {
            out.println("Vi verification failed");
        }
        storePropToFile(verip, veriFile);
        storePropToFile(certiP, certiFile);
    }

    // Helper methods
    public static void storePropToFile(Properties prop, String fileName) {
        try (FileOutputStream out = new FileOutputStream(fileName)) {
            prop.store(out, null);
        } catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }

    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (FileInputStream in = new FileInputStream(fileName)) {
            prop.load(in);
        } catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }

    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        String dir = "./storeFile/Nurkifli/"; // Root path
        String pairingParametersFileName = dir + "a.properties";
        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName = dir + "pk.properties";
        String secretKeyFileName = dir + "sk.properties";
        String certificateFileName = dir + "certi.properties";
        String verifyFileName = dir + "Veri.properties";
        String KGC = "KGC";
        String FA_i = "FA_i";
        String HA = "HA";
        String ID_i = "Vehicle_i";
        String ID_j = "Vehicle_j";
        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();
            systemInitialization(pairingParametersFileName, publicParameterFileName, mskFileName, KGC);
            registrationPhaseBetweenFAandHA(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName, KGC, FA_i);
            registrationPhaseBetweenFAandHA(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName, KGC, HA);
            registrationProcessBetweenMUandHA(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, KGC, ID_i);
            registrationProcessBetweenMUandHA(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, KGC, ID_j);
            mutualAuthenticationRoamingService(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, verifyFileName, certificateFileName, KGC, FA_i, ID_i);
            mutualAuthenticationRoamingService(pairingParametersFileName, publicParameterFileName, publicKeyFileName, secretKeyFileName, verifyFileName, certificateFileName, KGC, HA, ID_j);
            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }
    }
}