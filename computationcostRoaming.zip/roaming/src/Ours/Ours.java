package Ours;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.jpbc.PairingParameters;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

public class Ours {
    // --- Pairing & System Parameters ---
    static Pairing pairing;
    static Element g, h, g0, g1, g2, u, alpha;
    static Element P_pubA, P_pubB, sA, sB;
    static Map<String, Element[]> rsuKeys = new HashMap<>();         // RSU keys: [s, P_pub]
    static Map<String, Element[]> vehiclePublicKeys = new HashMap<>(); // Vehicle Public Keys: [U, W]
    static Map<String, Element[]> vehiclePrivateKeys = new HashMap<>(); // Vehicle Private Keys: [u, d, S, K]
    static Map<String, Element> vehiclePseudonyms = new HashMap<>();  // Vehicle Pseudonyms
    static Map<String, Element[]> vehiclePredicateVectors = new HashMap<>(); // Vehicle predicate vectors
    static Map<String, Element[]> vehicleRoamingCredentials = new HashMap<>(); // Vehicle Roaming Credentials: [T3, sigma_R-V, tau]

    // === System Initialization ===
    public static void systemInitialization(int securityParameter) {
        System.out.println("=== System Initialization (KGC) ===");

        // Load pairing parameters based on security parameter
        PairingParameters params = PairingFactory.getPairingParameters("storeFile/Ours/a.properties");
        pairing = PairingFactory.getPairing(params);
        PairingFactory.getInstance().setUsePBCWhenPossible(true);

        // (1) Select group G of order q and define bilinear map
        g = pairing.getG1().newRandomElement().getImmutable();

        // (2) Randomly choose parameters
        h = pairing.getG1().newRandomElement().getImmutable();
        g0 = pairing.getG1().newRandomElement().getImmutable();
        alpha = pairing.getZr().newRandomElement().getImmutable();

        // Compute derived parameters
        g1 = g.powZn(alpha).getImmutable();
        g2 = g0.powZn(alpha).getImmutable();
        u = pairing.pairing(g0, g1).getImmutable();

       // System.out.println("System parameters generated:");
      //  System.out.println("- g: " + g);
       // System.out.println("- h: " + h);
       // System.out.println("- g0: " + g0);
       // System.out.println("- g1: " + g1);
       // System.out.println("- g2: " + g2);
       // System.out.println("- u: " + u);

        // Initialize RSU keys
        initializeRSUs();
    }

    // Initialize RSUs with their master keys
    private static void initializeRSUs() {
        //System.out.println("\n=== RSU Initialization ===");

        // RSU_A initialization
        sA = pairing.getZr().newRandomElement().getImmutable();
        P_pubA = g.powZn(sA).getImmutable();
        rsuKeys.put("RSU_A", new Element[]{sA, P_pubA});

        // RSU_B initialization
        sB = pairing.getZr().newRandomElement().getImmutable();
        P_pubB = g.powZn(sB).getImmutable();
        rsuKeys.put("RSU_B", new Element[]{sB, P_pubB});

        //System.out.println("RSU_A initialized with public key: " + P_pubA);
        //System.out.println("RSU_B initialized with public key: " + P_pubB);
    }

    // === Vehicle Registration ===
    public static void registerVehicle(String vehicleID, String domainRSU, Element[] predicateVector) {
       // System.out.println("\n=== Registering Vehicle " + vehicleID + " with " + domainRSU + " ===");

        // Get RSU parameters
        Element[] rsuKey = rsuKeys.get(domainRSU);
        Element s_rsu = rsuKey[0];
        Element P_pub_rsu = rsuKey[1];

        // (1) Vehicle selects secret ui and computes Ui
        Element ui = pairing.getZr().newRandomElement().getImmutable();
        Element Ui = g.powZn(ui).getImmutable();

       // System.out.println("Vehicle secret ui: " + ui);
        //System.out.println("Vehicle public Ui: " + Ui);

        // (2) RSU processes registration
        Element wi = pairing.getZr().newRandomElement().getImmutable();
        Element Wi = g.powZn(wi).getImmutable();

        // Calculate pseudonym PID_i
        Element h_sA_Wi = hash1(s_rsu, Wi); // Simulate H0(s_A, W_i)
        Element PID_i = h_sA_Wi; // In real implementation would be XOR with ID_i

        // Calculate h_A1 = H1(P_pub_A, PID_i, U_i, W_i)
        Element h_A1 = hash1(P_pub_rsu, PID_i, Ui, Wi);

        // Calculate di = wi + s_A * h_A1
        Element di = wi.duplicate().add(s_rsu.duplicate().mul(h_A1)).getImmutable();

       // System.out.println("RSU generated wi: " + wi);
       // System.out.println("RSU generated Wi: " + Wi);
       // System.out.println("Vehicle pseudonym PID_i: " + PID_i);
       // System.out.println("Calculated h_A1: " + h_A1);
       // System.out.println("Partial private key di: " + di);

        // (3) KGC generates partial key based on predicate vector
        Element ri = pairing.getZr().newRandomElement().getImmutable();

        // Calculate sum of y_ik
        Element sum = pairing.getZr().newZeroElement();
        for (Element y_ik : predicateVector) {
            sum.add(y_ik);
        }

        // Calculate S_i and K_i
        Element term1 = g2.powZn(sum);
        Element pidHash = g1.powZn(PID_i);
        Element term2 = pidHash.mul(h).powZn(ri);
        Element Si = term1.mul(term2).getImmutable();
        Element Ki = g.powZn(ri).getImmutable();

       // System.out.println("KGC generated ri: " + ri);
        //System.out.println("Predicate vector sum: " + sum);
        //System.out.println("S_i: " + Si);
        //System.out.println("K_i: " + Ki);

        // Store vehicle keys and information
        vehiclePublicKeys.put(vehicleID, new Element[]{Ui, Wi});
        vehiclePrivateKeys.put(vehicleID, new Element[]{ui, di, Si, Ki});
        vehiclePseudonyms.put(vehicleID, PID_i);
        vehiclePredicateVectors.put(vehicleID, predicateVector);

        //System.out.println("Vehicle " + vehicleID + " registered successfully");
    }

    // === Roaming Authentication Credential Request (Join) ===
    public static void requestRoamingCredential(String vehicleID, String homeRSU) {
        //System.out.println("\n=== Vehicle " + vehicleID + " requesting roaming credential from " + homeRSU + " ===");

        // Get vehicle's keys and information
        Element[] publicKey = vehiclePublicKeys.get(vehicleID);
        Element[] privateKey = vehiclePrivateKeys.get(vehicleID);
        Element PID_i = vehiclePseudonyms.get(vehicleID);

        Element Ui = publicKey[0];
        Element Wi = publicKey[1];
        Element ui = privateKey[0];
        Element di = privateKey[1];

        // Get RSU information
        Element[] rsuKey = rsuKeys.get(homeRSU);
        Element s_rsu = rsuKey[0];
        Element P_pub_rsu = rsuKey[1];

        // (1) Vehicle generates request
        Element t0 = pairing.getZr().newRandomElement().getImmutable();
        Element t1 = pairing.getZr().newRandomElement().getImmutable();
        Element T0 = g.powZn(t0).getImmutable();
        Element T1 = g.powZn(t1).getImmutable();
        Element D0 = P_pub_rsu.powZn(t0).getImmutable();

        // Simulate M0 = H2(D0) XOR (PID_i || T1)
        Element M0 = hash2(D0); // In real implementation would XOR with (PID_i || T1)

        // Generate timestamp
        Element Gamma1 = pairing.getZr().newOneElement(); // Simulated timestamp

        // Generate signature
        Element h_i3 = hash3(publicKey, PID_i, M0, T0, T1, Gamma1);
        Element h_i4 = hash4(publicKey, PID_i, M0, T0, T1, Gamma1);

        // σi = t1 + h_i3*ui + h_i4*di
        Element signature_i = t1.duplicate()
                .add(h_i3.duplicate().mul(ui))
                .add(h_i4.duplicate().mul(di))
                .getImmutable();

        //System.out.println("Vehicle generated request parameters:");
        //System.out.println("- T0: " + T0);
       // System.out.println("- T1: " + T1);
       // System.out.println("- D0: " + D0);
       // System.out.println("- M0: " + M0);
       // System.out.println("- Signature σi: " + signature_i);

        // (2) RSU processes request
        // RSU computes D0' = T0^s_A and retrieves PID_i', T1'
        Element D0_prime = T0.powZn(s_rsu).getImmutable();
        // In real implementation: M0 XOR H2(D0') = (PID_i' || T1')

        // (3) RSU generates credential
        Element t2 = pairing.getZr().newRandomElement().getImmutable();
        Element t3 = pairing.getZr().newRandomElement().getImmutable();
        Element T2 = g.powZn(t2).getImmutable();
        Element T3 = g.powZn(t3).getImmutable();
        Element D1 = Ui.powZn(t2).getImmutable();

        // Create tau_i (ID_A, PID_i, extra info)
        Element tau_i = PID_i; // Simplified; would include domain ID and extra info

        // Simulate M1 = H2(D1) XOR (tau_i || T3)
        Element M1 = hash2(D1); // In real implementation would XOR with (tau_i || T3)

        // Generate timestamp
        Element Gamma2 = pairing.getZr().newOneElement().add(pairing.getZr().newOneElement()); // Simulated timestamp

        // Generate RSU signature for vehicle
        Element h_A2 = hash5(tau_i, P_pub_rsu, publicKey, T3);
        Element sigma_R_Vi = t3.duplicate().add(h_A2.duplicate().mul(s_rsu)).getImmutable();

       // System.out.println("RSU generated credential parameters:");
       // System.out.println("- T2: " + T2);
       // System.out.println("- T3: " + T3);
       // System.out.println("- D1: " + D1);
       // System.out.println("- M1: " + M1);
       // System.out.println("- tau_i: " + tau_i);
       // System.out.println("- Signature σ_R-Vi: " + sigma_R_Vi);

        // (4) Vehicle verifies and stores credential
        // Vehicle computes D1' = T2^ui
        Element D1_prime = T2.powZn(ui).getImmutable();
        // In real implementation: M1 XOR H2(D1') = (tau_i' || T3')

        // Verify RSU signature
        Element leftSide = g.powZn(sigma_R_Vi);
        Element rightSide = T3.mul(P_pub_rsu.powZn(h_A2));

        boolean signatureValid = leftSide.equals(rightSide);

        if (signatureValid) {
            // Store roaming credential
            Element[] credential = new Element[]{T3, sigma_R_Vi, tau_i};
            vehicleRoamingCredentials.put(vehicleID, credential);
           // System.out.println("Roaming credential verification successful and stored");
        } else {
           // System.out.println("Roaming credential verification failed!");
        }
    }

    // === Direct Roaming Authentication and Key Agreement ===
    public static void performDirectAuthentication(String vehicleID1, String vehicleID2) {
        //System.out.println("\n=== Direct Roaming Authentication between " + vehicleID1 + " and " + vehicleID2 + " ===");

        // Get vehicle information
        Element[] publicKey1 = vehiclePublicKeys.get(vehicleID1);
        Element[] privateKey1 = vehiclePrivateKeys.get(vehicleID1);
        Element PID_1 = vehiclePseudonyms.get(vehicleID1);
        Element[] credential1 = vehicleRoamingCredentials.get(vehicleID1);
        Element[] predicateVector1 = vehiclePredicateVectors.get(vehicleID1);

        Element[] publicKey2 = vehiclePublicKeys.get(vehicleID2);
        Element[] privateKey2 = vehiclePrivateKeys.get(vehicleID2);
        Element PID_2 = vehiclePseudonyms.get(vehicleID2);
        Element[] credential2 = vehicleRoamingCredentials.get(vehicleID2);
        Element[] predicateVector2 = vehiclePredicateVectors.get(vehicleID2);

        // Extract specific parameters
        Element U1 = publicKey1[0];
        Element W1 = publicKey1[1];
        Element u1 = privateKey1[0];
        Element d1 = privateKey1[1];
        Element S1 = privateKey1[2];
        Element K1 = privateKey1[3];

        Element U2 = publicKey2[0];
        Element W2 = publicKey2[1];
        Element u2 = privateKey2[0];
        Element d2 = privateKey2[1];
        Element S2 = privateKey2[2];
        Element K2 = privateKey2[3];

        Element T_13 = credential1[0];
        Element sigma_R_V1 = credential1[1];
        Element tau_1 = credential1[2];

        Element T_23 = credential2[0];
        Element sigma_R_V2 = credential2[1];
        Element tau_2 = credential2[2];

        // Get RSU public keys
        Element P_pubA = rsuKeys.get("RSU_A")[1];
        Element P_pubB = rsuKeys.get("RSU_B")[1];

        // (1) Vehicle 1 initiates authentication
        // Generate random values
        Element t_i = pairing.getZr().newRandomElement().getImmutable();
        Element t_A = pairing.getZr().newRandomElement().getImmutable();

        // Calculate parameters
        Element T_i = g.powZn(t_i).getImmutable();
        Element R_i = g.powZn(t_A).getImmutable();

        // Generate timestamp
        Element Gamma3 = pairing.getZr().newOneElement().add(pairing.getZr().newOneElement()).add(pairing.getZr().newOneElement());

        // Calculate signature components
        Element h_i6 = hash6(publicKey1, PID_1, P_pubA, T_i, Gamma3);
        Element h_i7 = hash7(publicKey1, PID_1, P_pubA, T_i, Gamma3);
        Element h_A2 = hash5(tau_1, P_pubA, publicKey1, T_13); // Reusing stored value
        Element h_A1 = hash1(P_pubA, PID_1, U1, W1); // Reusing stored value

        // Calculate signature
        Element sigma_V1 = sigma_R_V1.duplicate()
                .add(t_i)
                .add(h_i6.duplicate().mul(u1))
                .add(h_i7.duplicate().mul(d1))
                .getImmutable();

        // Create privacy vector (attributes V1 wants to share)
        Element[] x_i = new Element[predicateVector2.length];
        for (int i = 0; i < x_i.length; i++) {
            x_i[i] = pairing.getZr().newRandomElement().getImmutable(); // Random attributes
        }

        // Calculate attribute-based encryption components
        Element[] C_1k = new Element[x_i.length];
        for (int k = 0; k < x_i.length; k++) {
            Element term1 = pairing.pairing(g0, g1).powZn(x_i[k]);
            Element term2 = u.powZn(t_i);
            C_1k[k] = term1.mul(term2).getImmutable();
        }

        Element C_2 = g.powZn(t_i).getImmutable();
        Element PID_j_hash = g1.powZn(PID_2);
        Element C_3 = PID_j_hash.mul(h).powZn(t_i).getImmutable();

        //System.out.println("Vehicle " + vehicleID1 + " generated authentication message:");
        //System.out.println("- T_i: " + T_i);
        //System.out.println("- R_i: " + R_i);
       // System.out.println("- Signature σ_V1: " + sigma_V1);

        // (2) Vehicle 2 verifies and responds
        // Verify V1's signature
        Element leftSide = g.powZn(sigma_V1);
        Element term1 = T_13;
        Element term2 = P_pubA.powZn(h_A2);
        Element term3 = T_i;
        Element term4 = U1.powZn(h_i6);
        Element term5 = W1.mul(P_pubA.powZn(h_A1)).powZn(h_i7);
        Element rightSide = term1.mul(term2).mul(term3).mul(term4).mul(term5);

       // boolean signatureValid = leftSide.equals(rightSide);

       // if (!signatureValid) {
       //     System.out.println("Vehicle " + vehicleID2 + " authentication verification failed!");
        //    return;
       // }

        //System.out.println("Vehicle " + vehicleID1 + " authentication verified successfully");

        // Calculate attribute-based decryption
        // Q1 = product(C_1k^y_jk)
        Element Q_1 = pairing.getGT().newOneElement();
        for (int k = 0; k < predicateVector2.length; k++) {
            Q_1 = Q_1.mul(C_1k[k].powZn(predicateVector2[k]));
        }

        // Q2 = e(C_3, K_j)
        Element Q_2 = pairing.pairing(C_3, K2);

        // Q3 = e(C_2, S_j)
        Element Q_3 = pairing.pairing(C_2, S2);

        // Recover the inner product e(g0,g1)^<x_i,y_j>
        Element innerProduct = Q_1.mul(Q_2).div(Q_3);

        //System.out.println("Attribute-based inner product: " + innerProduct);

        // Generate V2's authentication response
        Element t_j = pairing.getZr().newRandomElement().getImmutable();
        Element t_B = pairing.getZr().newRandomElement().getImmutable();

        Element T_j = g.powZn(t_j).getImmutable();
        Element R_j = g.powZn(t_B).getImmutable();

        // Generate timestamp
        Element Gamma4 = Gamma3.duplicate().add(pairing.getZr().newOneElement());

        // Calculate signature components for V2
        Element h_j6 = hash6(publicKey2, PID_2, P_pubB, T_j, Gamma4);
        Element h_j7 = hash7(publicKey2, PID_2, P_pubB, T_j, Gamma4);
        Element h_B2 = hash5(tau_2, P_pubB, publicKey2, T_23);
        Element h_B1 = hash1(P_pubB, PID_2, U2, W2);

        // Calculate V2's signature
        Element sigma_V2 = sigma_R_V2.duplicate()
                .add(t_j)
                .add(h_j6.duplicate().mul(u2))
                .add(h_j7.duplicate().mul(d2))
                .getImmutable();

        // Calculate session key K_BA = R_i^t_B
        Element K_BA = R_i.powZn(t_B).getImmutable();

        //System.out.println("Vehicle " + vehicleID2 + " generated response:");
       // System.out.println("- T_j: " + T_j);
       // System.out.println("- R_j: " + R_j);
       // System.out.println("- Signature σ_V2: " + sigma_V2);
      //  System.out.println("- Session key K_BA: " + K_BA);

        // (3) Vehicle 1 verifies V2's response
        // Verify V2's signature
        leftSide = g.powZn(sigma_V2);
        term1 = T_23;
        term2 = P_pubB.powZn(h_B2);
        term3 = T_j;
        term4 = U2.powZn(h_j6);
        term5 = W2.mul(P_pubB.powZn(h_B1)).powZn(h_j7);
        rightSide = term1.mul(term2).mul(term3).mul(term4).mul(term5);

        //signatureValid = leftSide.equals(rightSide);

       // if (!signatureValid) {
       //     System.out.println("Vehicle " + vehicleID2 + " response verification failed!");
        //    return;
        //}

        //System.out.println("Vehicle " + vehicleID2 + " response verified successfully");

        // Calculate session key K_AB = R_j^t_A
        Element K_AB = R_j.powZn(t_A).getImmutable();

       // System.out.println("Vehicle " + vehicleID1 + " calculated session key K_AB: " + K_AB);

        // Verify that both session keys match
        boolean keysMatch = K_AB.equals(K_BA);
       // System.out.println("Session keys match: " + keysMatch);

        if (keysMatch) {
            System.out.println("Direct authentication and key agreement successful!");
        }
    }

    // === Hash functions (simplified) ===
    private static Element hash1(Element... inputs) {
        return hashHelper(1, inputs);
    }

    private static Element hash2(Element... inputs) {
        return hashHelper(2, inputs);
    }

    private static Element hash3(Element[] publicKey, Element PID, Element M0, Element T0, Element T1, Element timestamp) {
        return hashHelper(3, new Element[]{publicKey[0], publicKey[1], PID, M0, T0, T1, timestamp});
    }

    private static Element hash4(Element[] publicKey, Element PID, Element M0, Element T0, Element T1, Element timestamp) {
        return hashHelper(4, new Element[]{publicKey[0], publicKey[1], PID, M0, T0, T1, timestamp});
    }

    private static Element hash5(Element tau, Element P_pub, Element[] publicKey, Element T3) {
        return hashHelper(5, new Element[]{tau, P_pub, publicKey[0], publicKey[1], T3});
    }

    private static Element hash6(Element[] publicKey, Element PID, Element P_pub, Element T, Element timestamp) {
        return hashHelper(6, new Element[]{publicKey[0], publicKey[1], PID, P_pub, T, timestamp});
    }

    private static Element hash7(Element[] publicKey, Element PID, Element P_pub, Element T, Element timestamp) {
        return hashHelper(7, new Element[]{publicKey[0], publicKey[1], PID, P_pub, T, timestamp});
    }

    // Helper function for hash simulation
    private static Element hashHelper(int hashFunction, Element[] inputs) {
        // Simple hash simulation using the sum of input elements and hash function ID
        Element result = pairing.getZr().newElement(hashFunction);
        for (Element input : inputs) {
            if (input != null) {
                // Convert the BigInteger value to an Element
                Element valueElement = pairing.getZr().newElement();
                result.add(valueElement);
            }
        }
        return result.getImmutable();
    }

    // === Main Simulation ===
    public static void main(String[] args) {
        for (int j = 0; j < 10; j++) {


            systemInitialization(256);


            int vectorSize = 3;
            Element[] Vector1 = new Element[vectorSize];
            Element[] Vector2 = new Element[vectorSize];

            for (int i = 0; i < vectorSize; i++) {
                Vector1[i] = pairing.getZr().newRandomElement().getImmutable();
                Vector2[i] = pairing.getZr().newRandomElement().getImmutable();
            }


            registerVehicle("Vehicle_A", "RSU_A", Vector1);
            registerVehicle("Vehicle_B", "RSU_B", Vector2);

            requestRoamingCredential("Vehicle_A", "RSU_A");
            requestRoamingCredential("Vehicle_B", "RSU_B");

            long start = System.currentTimeMillis();
            performDirectAuthentication("Vehicle_A", "Vehicle_B");
            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }
    }
}