package Xue;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;
import java.math.BigInteger;

import static java.lang.System.out;

public class Xue {
    // 模拟椭圆曲线参数

    public static void setup0(String pairingFile, String publicFile) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);



    }
    // 模拟哈希函数
    private static String hash(String input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(input.getBytes());
        return new BigInteger(1, hashBytes).toString(16);
    }

    // 异或操作
    private static String xor(String a, String b) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < Math.min(a.length(), b.length()); i++) {
            result.append((char) (a.charAt(i) ^ b.charAt(i)));
        }
        return result.toString();
    }

    // 存储属性到文件
    private static void storePropToFile(Properties prop, String fileName) {
        try (FileOutputStream out = new FileOutputStream(fileName)) {
            prop.store(out, null);
        } catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }

    // 从文件加载属性
    private static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (FileInputStream in = new FileInputStream(fileName)) {
            prop.load(in);
        } catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }

    // 初始化系统参数
    public static void setup(String pairingFile,String publicFile, String mskFile, String KGC) {
        // HTA和FTA生成私钥和公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element d_HA = bp.getZr().newRandomElement().getImmutable();
        Element P_HA = P.powZn(d_HA).getImmutable();

        Element d_FA = bp.getZr().newRandomElement().getImmutable();
        Element P_FA = P.powZn(d_FA).getImmutable();

        // 生成会话密钥
        Element K_FH = bp.getZr().newRandomElement().getImmutable();

        // 保存公共参数

        pubProp.setProperty("P_HA", P_HA.toString());
        pubProp.setProperty("P_FA", P_FA.toString());
        storePropToFile(pubProp, publicFile);

        // 保存主私钥
        Properties mskProp = new Properties();
        mskProp.setProperty("d_HA", Base64.getEncoder().encodeToString(d_HA.toBytes()));
        mskProp.setProperty("d_FA", Base64.getEncoder().encodeToString(d_FA.toBytes()));
        mskProp.setProperty("K_FH", Base64.getEncoder().encodeToString(K_FH.toBytes()));
        storePropToFile(mskProp, mskFile);
    }

    // 注册车辆
    public static void registerU(String pairingFile,String publicFile, String vehicleFile, String vehicleID) throws NoSuchAlgorithmException {
        // 读取公共参数
        Properties pubProp = loadPropFromFile(publicFile);
        Pairing bp=PairingFactory.getPairing(pairingFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_HA = bp.getG1().newElementFromBytes(pubProp.getProperty("P_HA").getBytes()).getImmutable();

        // 车辆生成签名
        Element s_i = bp.getZr().newRandomElement().getImmutable();
        Element r_i = bp.getZr().newRandomElement().getImmutable();
        String signature = hash(vehicleID + s_i.toString() + r_i.toString());

        // 车辆生成伪身份
        Element a_i = bp.getZr().newRandomElement().getImmutable();
        String PID_i = hash(vehicleID + a_i.toString());
        String PID_prime_i = hash(vehicleID + P_HA.toString());
        String S_i = xor(hash(vehicleID + s_i.toString()), a_i.toString());

        // 保存车辆信息
        Properties vehicleProp = new Properties();
        vehicleProp.setProperty("vehicleID", vehicleID);
        vehicleProp.setProperty("PID_i", PID_i);
        vehicleProp.setProperty("PID_prime_i", PID_prime_i);
        vehicleProp.setProperty("S_i", S_i);
        storePropToFile(vehicleProp, vehicleFile);
    }

    // 注册RSU
    public static void registerAP(String pairingFile, String publicFile, String rsuFile, String rsuID) throws NoSuchAlgorithmException {
        // 读取公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();

        // 生成私钥和公钥
        Element r = bp.getZr().newRandomElement().getImmutable();
        Element P_RSU = P.powZn(r).getImmutable();

        // 保存信息
        Properties rsuProp = new Properties();
        rsuProp.setProperty("rsuID", rsuID);
        rsuProp.setProperty("P_RSU", P_RSU.toString());
        storePropToFile(rsuProp, rsuFile);
    }

    // 认证
    public static void authentication(String pairingFile, String publicFile, String vehicleFile, String rsuFile, String mskFile) throws NoSuchAlgorithmException {
        // 读取公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_HA = bp.getG1().newElementFromBytes(pubProp.getProperty("P_HA").getBytes()).getImmutable();
        Element P_FA = bp.getG1().newElementFromBytes(pubProp.getProperty("P_FA").getBytes()).getImmutable();

        // 读取用户信息
        Properties vehicleProp = loadPropFromFile(vehicleFile);
        String vehicleID = vehicleProp.getProperty("vehicleID");
        String PID_i = vehicleProp.getProperty("PID_i");
        String S_i = vehicleProp.getProperty("S_i");

        // 读取信息
        Properties rsuProp = loadPropFromFile(rsuFile);
        String rsuID = rsuProp.getProperty("rsuID");
        Element P_RSU = bp.getG1().newElementFromBytes(rsuProp.getProperty("P_RSU").getBytes()).getImmutable();

        // 读取主私钥
        Properties mskProp = loadPropFromFile(mskFile);
        Element d_HA = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(mskProp.getProperty("d_HA")));
        Element d_FA = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(mskProp.getProperty("d_FA")));
        Element K_FH = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(mskProp.getProperty("K_FH")));

        // 选择随机数并计算相关值
        Element x_i = bp.getZr().newRandomElement().getImmutable();
        Element P_V = P.powZn(x_i).getImmutable();
        Element P_prime_V = P_V.powZn(P_RSU);

        String timestamp = "timestamp"; // 假设的时间戳
        String Mv1 = xor(PID_i, hash(P_V.toString() + timestamp));
        String Mv2 = hash(P_HA.toString() + PID_i + timestamp);
        String Mi = xor(Mv2, hash(S_i));



        // 处理认证请求
        Element Pr = P_RSU.powZn(x_i);
        String PID_i_decoded = xor(Mv1, hash(Pr.toString() + timestamp));


        Element P_prime_R = P_RSU.powZn(d_FA);
        String Mr1 = xor(PID_i_decoded, hash(P_prime_R.toString() + timestamp));

        Element Pf = P_RSU.powZn(d_FA);
        String PID_i_decoded_FTA = xor(Mr1, hash(Pf.toString() + timestamp));


        Element P_prime_f = P_FA.powZn(d_HA);
        String Mf1 = xor(PID_i_decoded_FTA, hash(P_prime_f.toString() + timestamp) + K_FH.toString());

        Element P_H = P_FA.powZn(d_HA);
        String PID_i_decoded_HTA = xor(Mf1, hash(P_H.toString() + timestamp) + K_FH.toString());

        String signature = hash(vehicleID + S_i);


        // HTA生成共享密钥
        Element K_s = P_V.powZn(P_RSU).powZn(P_FA).getImmutable();
        String E_KS = xor(K_s.toString(), PID_i_decoded_HTA + timestamp);


    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        String dir = "./storeFile/Yadav/"; // Root path
        String pairingFile = dir+"a.properties";
        String publicFile = dir+"public.properties";
        String mskFile = dir+"msk.properties";
        String uFile = dir+"vehicle.properties";
        String apFile = dir+"rsu.properties";
        String KGC = "KGC";
        String uID = "u123";
        String uIDu = "user";
        String apID = "ap456";
        String apID2 = "ap456";

            long start = System.currentTimeMillis();
            // 初始化系统
            setup0(pairingFile, publicFile);
            setup(pairingFile, publicFile, mskFile, KGC);
            // 注册yonghu
            registerU(pairingFile, publicFile, uFile, uID);
            registerU(pairingFile, publicFile, uFile, uIDu);
            // 注册ap
            registerAP(pairingFile, publicFile, apFile, apID);
            registerAP(pairingFile, publicFile, apFile, apID2);
            // 认证
            authentication(pairingFile, publicFile, uFile, apFile, mskFile);
            long end = System.currentTimeMillis();
            System.out.println(end - start);


    }
}

